import{c as s,n as e}from"./index-IcCdQ3HA.js";/**
 * @license lucide-react v0.441.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=s("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]]);async function o(){return e}async function r(c){return e.find(n=>n.id===c)}export{t as C,r as a,o as g};
