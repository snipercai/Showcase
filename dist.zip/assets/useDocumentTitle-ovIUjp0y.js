import{r as o}from"./index-IcCdQ3HA.js";function r(t){o.useEffect(()=>{const e=document.title;return document.title=t,()=>{document.title=e}},[t])}export{r as u};
